In this tutorial, you will manage your OCR app by Helm.

## How-to Guide
```shell
cd ocr_chart
helm upgrade --install ocr .
```